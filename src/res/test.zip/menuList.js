const menuList = [
    {
        title: 'Home', // 菜单标题名称
        key: '/home', // 对应的path
    },
    {
        title: 'Upload Video',
        key: '/uploadVideo',
    },
    {
        title: 'Live Record',
        key: '/liveRecord',
    },
    {
        title: 'About',
        key: '/about',
    },


]

export default menuList